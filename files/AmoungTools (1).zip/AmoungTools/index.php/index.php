<?php
require_once __DIR__.'\connexion.php';

if (!empty($_FILES)){

  $file_name= $_FILES['fichier']['name'];
  $file_extension= strrchr($file_name, ".");
$file_tmp_name= $_FILES['fichier']['tmp_name'];
$file_dest= 'files/'.$file_name;
                                                                                      


$extensions_autorisees = array ('.zip','.ZIP');
$extensions_autorisees = array ('.pdf','.PDF');

if (in_array($file_extension, $extensions_autorisees)){

    if (move_uploaded_file($file_name, $file_dest)){
    $req =$db->prepare ('insert into files (id,name,files_url) values (0,?,?)'); 
    $req -> execute(array($file_name,$file_dest));
    
    echo 'fichier envoyé avec succès';
      }
  
 else {

  echo 'Attention seuls les fichiers PDF et ZIP sont autorisés!';
}
}

  
?>

<!DOCTYPE html>
 <html>
     <head>
      <title>Upload de fichiers</title>
         <meta charset="UTF-8" />
     </head>

     <body>
      <h1>Upload un fichier en PDF</h1>

         <form name="fo" method="post" action="index.php" enctype="multipart/form-data">         
             <input type="file" multiple="multiple" name="fichier"  /> 
             
<select name="typeFile">
    <option value="client">Client</option>
    <option value="fournisseur">Fournisseur</option>

</select>  


<select name="Client">
    <option value="Commande client">Commande client</option>
    <option value="facture"> facture</option>

</select> 

<select name="Fournisseur">
    <option value="Commande fournisseur">Commande client</option>
    <option value="facture"> liasse documentaire</option>

</select> 




                   
             <br>
             <input type="submit" name="valider" value="Envoyer le fichier" />

          </form>                                                                                                        
      </body>    
  </html>     
       
       