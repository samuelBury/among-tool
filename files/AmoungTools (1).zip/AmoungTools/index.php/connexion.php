<?php

try {

	$db = new PDO ('mysql:host=localhost; dbname=amoung','root','');
 

}catch(PDOException $e){

die ('Erreur:'.$e->getMessage());
}

